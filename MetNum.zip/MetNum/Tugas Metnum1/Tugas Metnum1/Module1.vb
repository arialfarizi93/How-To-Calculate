﻿Module Module1

    Sub Main()
        Dim bil1, bil2 As Double
        Dim Pilihan As Integer
        Dim kal As New Kalkulator

        Console.WriteLine(" Operasi Hitung ")


        Console.WriteLine(" 1. Penambahan ")
        Console.WriteLine(" 2. Pengurangan ")
        Console.WriteLine(" 3. Pembagian ")
        Console.WriteLine(" 4. Pangkat ")
        Console.WriteLine(" 5. Deret ")
        Console.Write(" Pilihan : ")



        Pilihan = Console.ReadLine
        Console.Clear()
        Console.Write(" Masukkan angka 1 : ")
        bil1 = Console.ReadLine()

        Console.Write(" Masukan angka 2  : ")
        bil2 = Console.ReadLine()

        Console.WriteLine()


        Select Case UCase(Pilihan)
            Case "1"
                Console.Write(" Hasil Penambahan  : " & kal.tambah(bil1, bil2))
                Console.ReadLine()
            Case "2"
                Console.Write(" Hasil Pengurangan : " & kal.kurang(bil1, bil2))
                Console.ReadLine()
            Case "3"
                Console.Write(" Hasil Pembagian   : " & kal.bagi(bil1, bil2))
                Console.ReadLine()
            Case "4"
                Console.WriteLine(" Hasil Pangkat : " & kal.pangkat(bil1, bil2))
                Console.ReadLine()
            Case "5"
                Console.WriteLine(" Hasil Deret   : " & kal.deret(bil1, bil1))
                Console.WriteLine(" Hasil Deret   : " & kal.deret(bil2, bil2))
                Console.ReadLine()
            Case Else
                Console.Write(" Wah Lasut ")
                Console.ReadLine()
        End Select

    End Sub

End Module
