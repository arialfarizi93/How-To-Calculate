#include <conio.h>
#include <stdio.h>

int bil1,bil2;
int tambah(int a, int b);
int kurang(int a, int b);
int perkalian(int a,int b);
int pembagian(int a, int b);
int hasil;

	main(){
		//kamus
		int pilihan, menu;
		char input [30];
		
		//isi
		menu :
			printf("1. Menghitung A+B \n");
			printf("2. Menghitung A-B \n");
			printf("3. Menghitung A/B \n");
			printf("4. Menghitung A^B \n");
			printf("5. Menghitung Deret f(x)=2x^2-4+1 \n");
			printf("Masukan Pilihan Anda :\n");
			scanf("%d",&pilihan);
		
			switch (pilihan)
			{
				case 1	:	
							printf("Input A : ");
							scanf("%i",&bil1);
							printf("Input B : ");
							scanf("%i",&bil2);
								hasil = bil1 + bil2 ;
								return hasil;
							goto menu;
							break;
				case 2	:	
							printf("Input A : ");
							scanf("%i",&bil1);
							printf("Input B : ");
							scanf("%i",&bil2);
								hasil = bil1 - bil2;
								return hasil;
							break;
				case 3	:	
							printf("Input A : ");
							scanf("%i",&bil1);
							printf("Input B : ");
							scanf("%i",&bil2);
								hasil = bil1*bil2;
								return hasil;
							break;
				case 4	:	
							printf("Input A : ");
							scanf("%i",&bil1);
							printf("Input B : ");
							scanf("%i",&bil2);
							
								hasil = bil1/bil2;
								return hasil;
							break;
				case 5	:	printf("Input A : ");
							scanf("%i",&bil1);
							printf("Input B : ");
							scanf("%i",&bil2);
							break;
				default :	printf(" Inputan yang anda masukan salah..");
			}

		getch();
	}
